import React, { useCallback, useContext, useEffect } from 'react';
import { WalletContext , Transaction } from '../Context/Context';
import data from '../Data/data.json';
import WalletUI from '../Components/UI/TransactionList'


const Wallet: React.FC = () => {
    const walletContext = useContext(WalletContext);
    
    useEffect(() => {
        const storedBalance = localStorage.getItem('balance');
        if (storedBalance) {
            walletContext.setBalance(Number(storedBalance));
        }
    }, []);
    
    useEffect(() => {
        localStorage.setItem('balance', walletContext.balance.toString());
    }, [walletContext.balance]);

    const increaseBalance = useCallback(() => {
        walletContext.setBalance(prevBalance => prevBalance + 1);
    }, [walletContext.setBalance]);

    return (
        <WalletUI increaseBalance={increaseBalance}/>
    );
}

export default Wallet;
