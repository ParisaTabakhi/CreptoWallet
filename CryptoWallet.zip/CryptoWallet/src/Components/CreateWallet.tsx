
import React, { useContext, useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { WalletContext } from '../Context/Context';
import GenerateWords from './GenerateWords';
import { useNavigate } from 'react-router-dom';
import CreateWalletUI from './UI/CreateWallet';

const CreateWallet: React.FC = () => {
    const uuidContext = useContext(WalletContext);
    const [words, setWords] = useState<string[]>([]);
    const [isWordsGenerated, setIsWordsGenerated] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const storedWords = localStorage.getItem('generatedWords');
        if (storedWords) {
            setIsWordsGenerated(true); 
            setWords(JSON.parse(storedWords));
            navigate('/Wallet'); 
        }
    }, []);

    const handleGenerateWords = (generatedWords: string[]) => {
        setWords(generatedWords);
        setIsWordsGenerated(true);
        
        localStorage.setItem('generatedWords', JSON.stringify(generatedWords));
    };

    const handleCreateWallet = () => {
        const newUuid = uuidv4();
        
        if (uuidContext && uuidContext.setUuid) {
            uuidContext.setUuid(newUuid);
        }
        
        localStorage.setItem('uuid', newUuid);
        navigate('/Wallet');
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
            {!isWordsGenerated && <GenerateWords onWordsGenerated={handleGenerateWords} />}
            {isWordsGenerated && (
                <CreateWalletUI words={words} onCreateWallet={handleCreateWallet} />
            )}
        </div>
    );
};

export default CreateWallet;
