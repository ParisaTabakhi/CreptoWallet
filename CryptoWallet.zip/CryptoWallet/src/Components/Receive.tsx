import React, { useContext } from 'react';
import { WalletContext } from '../Context/Context';
import ReceiveUI from '../Components/UI/Receive';

const Receive: React.FC = () => {
    const uuidContext = useContext(WalletContext);
    return (
        <ReceiveUI uuid={uuidContext.uuid} />
    );
}

export default Receive;
