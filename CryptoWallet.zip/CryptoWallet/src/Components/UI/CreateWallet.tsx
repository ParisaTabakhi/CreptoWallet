import React from 'react';

interface CreateWalletUIProps {
    words: string[];
    onCreateWallet: () => void;
}

const CreateWalletUI: React.FC<CreateWalletUIProps> = ({ words, onCreateWallet }) => {
    return (
        <div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-4 w-full max-w-xl">
                {words.map((word, index) => (
                    <div key={index} className="bg-blue-200 text-center p-3 rounded shadow">
                        {word}
                    </div>
                ))}
            </div>
            <button 
                className='bg-blue-500 text-white font-bold my-3 py-2 px-4 rounded hover:bg-blue-600' 
                onClick={onCreateWallet}>
                Create Wallet
            </button>
        </div>
    );
};

export default CreateWalletUI;
