import React from 'react';
import QRCode from 'qrcode.react';

interface ReceiveUIProps {
    uuid: string;
}

const ReceiveUI: React.FC<ReceiveUIProps> = ({ uuid }) => {
    return (
        <div className="flex items-center justify-center h-screen bg-blue-50">
            <div className="bg-white shadow-lg rounded-lg p-6 text-center">
                <h3 className='text-2xl text-blue-700 font-bold mb-5'>Wallet Address</h3>
                <div className='flex items-center justify-center'>
                    <QRCode value={uuid} size={128} />
                </div>
                {uuid && <p className="mt-4 text-blue-700">{uuid}</p>}
            </div>
        </div>
    );
}

export default ReceiveUI;
