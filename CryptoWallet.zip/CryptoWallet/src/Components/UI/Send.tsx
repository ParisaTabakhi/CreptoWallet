import React, { useContext } from 'react';
import { WalletContext } from '../../Context/Context';

const SendUI: React.FC<{ handleSubmit: (e: React.FormEvent<HTMLFormElement>) => void; error: string }> = ({ handleSubmit, error }) => {
    const walletContext = useContext(WalletContext);
    
    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-100">
            <div className="bg-white shadow-lg rounded-lg p-6 max-w-sm w-full">
                <h3 className="text-blue-500 text-xl font-bold text-center mb-4">
                    Balance: {walletContext.balance}
                </h3>
                <form name='send' onSubmit={handleSubmit} className="mt-4">
                    <input 
                        placeholder='Wallet Address' 
                        type='text' 
                        name='address'
                        className="border border-blue-400 p-2 rounded mb-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onChange={(e) => walletContext.setFormData({ ...walletContext.formData, [e.target.name]: e.target.value })} 
                    />
                    <input 
                        placeholder='Amount' 
                        type='text' 
                        name='amount'
                        className="border border-blue-400 p-2 rounded mb-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
                        onChange={(e) => walletContext.setFormData({ ...walletContext.formData, [e.target.name]: e.target.value })} 
                    />
                    <button 
                        type='submit' 
                        className="bg-blue-500 text-white p-2 rounded w-full hover:bg-blue-700 transition duration-300"
                    >
                        Send
                    </button>
                    {error && <p className='text-red-500 mt-2 text-center'>{error}</p>}
                </form>
            </div>
        </div>
    );
}

export default SendUI;
